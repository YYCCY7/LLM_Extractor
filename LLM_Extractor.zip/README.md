# STKG AI知识图谱抽取前端

这是一个基于Vue 3和Element Plus的AI知识图谱抽取系统前端界面。

## 功能特性

- 🔐 **自动登录**: 应用启动时自动使用admin/admin登录获取认证token
- 🎯 **知识图谱选择**: 支持选择已有的知识图谱进行抽取
- 📁 **文件上传**: 支持拖拽上传txt、doc、docx、pdf格式文档
- ⚙️ **参数配置**: 可配置分片大小、重叠大小、并行线程数等参数
- 🔧 **本体校验**: 支持启用/禁用本体校验和去重合并
- 📝 **自定义Prompt**: 支持加载默认模板和自定义抽取提示词
- ⚡ **同步/异步抽取**: 支持同步和异步两种抽取模式
- 📊 **进度监控**: 实时显示异步任务的抽取进度
- 📈 **结果展示**: 以表格形式展示抽取的实体和关系
- 💾 **结果保存**: 支持将抽取结果保存到知识图谱

## 技术栈

- **Vue 3**: 使用Composition API
- **Element Plus**: UI组件库
- **Vite**: 构建工具
- **Axios**: HTTP客户端
- **Vue Router**: 路由管理

## 安装和运行

### 1. 安装依赖

```bash
cd web
npm install
```

### 2. 启动开发服务器

```bash
npm run dev
```

前端将在 http://localhost:3000 启动

### 3. 构建生产版本

```bash
npm run build
```

## 项目结构

```
web/
├── src/
│   ├── api/           # API接口
│   │   ├── index.js   # axios配置
│   │   └── aiExtract.js # AI抽取相关API
│   ├── router/        # 路由配置
│   ├── views/         # 页面组件
│   │   └── AIExtract.vue # 主页面
│   ├── App.vue        # 根组件
│   └── main.js        # 入口文件
├── index.html         # HTML模板
├── package.json       # 项目配置
├── vite.config.js     # Vite配置
└── README.md          # 项目说明
```

## API接口

### 认证相关接口

- `POST /auth/login` - 用户登录（自动使用admin/admin）

### AI抽取相关接口

- `POST /ai/extract` - 同步抽取
- `POST /ai/extract/async` - 异步抽取
- `GET /ai/extract/progress/{taskId}` - 获取任务进度
- `GET /ai/extract/prompt/{kgId}` - 获取默认prompt模板
- `GET /ai/extract/persistent` - 结果入库

### 知识图谱相关接口

- `GET /kg/list` - 获取知识图谱列表
- `GET /kg/{id}` - 获取知识图谱详情

## 使用说明

### 0. 自动登录
应用启动时会自动使用用户名 `admin` 和密码 `admin` 进行登录，获取认证token。所有后续的API请求都会自动携带 `Authorization: Bearer <token>` header。

### 1. 选择知识图谱
从下拉列表中选择要使用的知识图谱，系统会自动加载该图谱的本体信息。

### 2. 上传文档
支持拖拽或点击上传文档，支持txt、doc、docx、pdf格式，文件大小不超过50MB。

### 3. 配置抽取参数
- **分片大小**: 文本分片的token数量，默认2000
- **分片重叠**: 相邻分片的重叠token数量，默认500
- **并行线程数**: 并行处理的线程数，默认4
- **本体校验**: 是否启用本体校验，默认开启
- **去重合并**: 是否启用去重合并，默认开启

### 4. 自定义Prompt
可以加载默认的抽取模板，也可以自定义抽取提示词，必须包含`{text_chunk}`占位符。

### 5. 开始抽取
- **同步抽取**: 立即返回抽取结果，适合小文件
- **异步抽取**: 返回任务ID，适合大文件，可监控进度

### 6. 查看结果
抽取完成后可以查看：
- 实体列表：显示抽取的实体及其属性
- 关系列表：显示实体间的关系
- 统计信息：实体数量、关系数量、实体类型数量

### 7. 保存结果
可以将抽取结果保存到选定的知识图谱中。

## 配置说明

### 代理配置
在`vite.config.js`中配置了API代理，将请求代理到后端服务器：

```javascript
proxy: {
  '/api': {
    target: 'http://localhost:9090',
    changeOrigin: true
  }
}
```

### 后端服务
确保后端Spring Boot服务运行在`http://localhost:9090`，或者修改代理配置中的target地址。

## 注意事项

1. 确保后端服务正常运行
2. 文件上传大小限制为50MB
3. 异步任务会定期查询进度，任务完成后会自动停止查询
4. 抽取结果会保存在内存中，刷新页面会丢失

## 开发说明

### 添加新功能
1. 在`src/api/`目录下添加新的API接口
2. 在`src/views/`目录下创建新的页面组件
3. 在`src/router/index.js`中添加路由配置

### 样式修改
项目使用Element Plus组件库，可以通过CSS变量或直接修改样式来自定义外观。

### 构建部署
构建后的文件在`dist`目录中，可以部署到任何静态文件服务器。 