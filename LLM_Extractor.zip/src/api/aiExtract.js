import api from './index'
import JSONbig from 'json-bigint'

/**
 * AI抽取相关API
 */
export const aiExtractAPI = {
  /**
   * 同步抽取
   * @param {FormData} formData - 包含文件和参数的表单
   * @returns {Promise<Object>} - 抽取结果
   */
  extractSync: (formData) => {
    return api.post('/ai/extract', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      timeout: 300000 // 300秒超时
    })
  },

  /**
   * 异步抽取
   * @param {FormData} formData - 包含文件和参数的表单
   * @returns {Promise<Object>} - 任务信息
   */
  extractAsync: (formData) => {
    return api.post('/ai/extract/async', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
  },

  /**
   * 获取任务进度
   * @param {string|number} taskId - 任务ID
   * @returns {Promise<Object>} - 进度信息
   */
  getProgress: (taskId) => {
    return api.get(`/ai/extract/progress/${taskId}`)
  },

  /**
   * 获取默认prompt模板
   * @param {string|number} kgId - 知识图谱ID
   * @returns {Promise<Object>} - 模板内容
   */
  getDefaultPrompt: (kgId) => {
    return api.get(`/ai/extract/prompt/${kgId}`)
  },

  /**
   * 结果入库
   * @param {string|number} kgId - 知识图谱ID
   * @param {string} jsonPath - 结果文件路径
   * @returns {Promise<Object>} - 入库结果
   */
  loadToGraphDB: (kgId, jsonPath) => {
    return api.get('/ai/extract/persistent', {
      params: { kgId, jsonPath }
    })
  }
}

/**
 * 知识图谱相关API
 */
export const kgAPI = {
  /**
   * 获取知识图谱列表
   * @param {Object} params - 分页参数
   * @returns {Promise<Object>} - 图谱列表
   */
  getKGList: (params) => {
    // 用原生axios请求，responseType设为'text'，手动用json-bigint解析
    return api.get('/kg/list', { params, responseType: 'text', transformResponse: [] })
      .then(res => {
        // res是字符串，这里用json-bigint解析
        const data = JSONbig({ storeAsString: true }).parse(res)
        return data
      })
  },

  /**
   * 获取知识图谱详情
   * @param {string|number} id - 图谱ID
   * @returns {Promise<Object>} - 图谱详情
   */
  getKGInfo: (id) => {
    return api.get(`/kg/${id}`)
  }
}
