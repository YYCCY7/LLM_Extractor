import axios from 'axios'
import { ElMessage } from 'element-plus'

// 创建axios实例
const api = axios.create({
  baseURL: '/api',
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json'
  }
})

// 自动登录获取token
let authToken = null;
let isLoggingIn = false;

// 自动登录函数
async function autoLogin() {
  if (isLoggingIn) return; // 防止重复登录
  if (authToken) return; // 已有token
  
  isLoggingIn = true;
  try {
    console.log('正在自动登录...');
    const response = await axios.post('/api/auth/login', {
      userName: 'admin',
      password: 'admin'
    });
    
    if (response.data.code === 200) {
      authToken = response.data.data;
      localStorage.setItem('auth_token', authToken);
      console.log('自动登录成功，token已保存');
    } else {
      console.error('自动登录失败:', response.data.message);
    }
  } catch (error) {
    console.error('自动登录请求失败:', error);
  } finally {
    isLoggingIn = false;
  }
}

// 请求拦截器
api.interceptors.request.use(
  async config => {
    // 如果没有token，先尝试自动登录
    if (!authToken) {
      await autoLogin();
    }
    
    // 添加Authorization header
    if (authToken) {
      config.headers['Authorization'] = `Bearer ${authToken}`;
    }
    
    return config;
  },
  error => {
    return Promise.reject(error)
  }
)

// 响应拦截器：统一错误处理
api.interceptors.response.use(
  res => res.data,
  err => {
    // 统一弹出错误提示
    ElMessage.error(err.response?.data?.message || err.message || '网络错误')
    return Promise.reject(err)
  }
)

// 初始化时尝试从localStorage恢复token
authToken = localStorage.getItem('auth_token');

export default api
// 说明：所有API请求都应通过本实例发起，组件只需处理业务异常，无需重复try/catch。