<template>
  <div class="knowledge-graph-container">
    <div class="graph-header">
      <div class="graph-controls">
        <el-button size="small" @click="resetSimulation">重置布局</el-button>
        <el-button size="small" @click="fitToScreen">适应屏幕</el-button>
        <el-button size="small" @click="togglePhysics">{{ physicsEnabled ? '关闭' : '开启' }}物理引擎</el-button>
        <el-button size="small" @click="exportGraph">导出图片</el-button>
      </div>
      <div class="graph-stats">
        <span>节点: {{ nodes.length }}</span>
        <span>关系: {{ relationships.length }}</span>
      </div>
    </div>
    
    <div ref="graphContainer" class="graph-container">
      <svg ref="svg" class="graph-svg"></svg>
    </div>
    
    <!-- 节点详情弹窗 -->
    <el-dialog
      v-model="showNodeDetail"
      title="节点详情"
      width="500px"
      :before-close="closeNodeDetail"
    >
      <div v-if="selectedNode" class="node-detail">
        <div class="detail-item">
          <label>实体ID:</label>
          <span>{{ selectedNode.id }}</span>
        </div>
        <div class="detail-item">
          <label>实体类型:</label>
          <span>{{ selectedNode.type }}</span>
        </div>
        <div v-if="selectedNode.properties && Object.keys(selectedNode.properties).length > 0" class="detail-item">
          <label>属性:</label>
          <div class="properties-list">
            <div v-for="(value, key) in selectedNode.properties" :key="key" class="property-item">
              <span class="property-key">{{ key }}:</span>
              <span class="property-value">{{ value }}</span>
            </div>
          </div>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { ref, onMounted, onUnmounted, watch, nextTick } from 'vue'
import * as d3 from 'd3'

export default {
  name: 'KnowledgeGraph',
  props: {
    nodes: {
      type: Array,
      default: () => []
    },
    relationships: {
      type: Array,
      default: () => []
    }
  },
  setup(props) {
    const graphContainer = ref(null)
    const svg = ref(null)
    const simulation = ref(null)
    const physicsEnabled = ref(true)
    const showNodeDetail = ref(false)
    const selectedNode = ref(null)
    
    // 颜色生成器
    const colorScale = d3.scaleOrdinal(d3.schemeCategory10)
    
    // 转换数据格式
    const transformData = () => {
      // 为每个节点分配颜色
      const nodesWithColor = props.nodes.map(node => ({
        ...node,
        color: getNodeColor(node.type)
      }))
      
      // 创建节点映射
      const nodeMap = new Map(nodesWithColor.map(node => [node.id, node]))
      
      return {
        nodes: nodesWithColor,
        links: props.relationships.map((rel, index) => ({
          id: index,
          source: nodeMap.get(rel.sourceNodeId),
          target: nodeMap.get(rel.targetNodeId),
          type: rel.type,
          description: rel.description
        })).filter(link => link.source && link.target) // 过滤掉无效的链接
      }
    }
    
    // 获取节点颜色
    const getNodeColor = (type) => {
      return colorScale(type)
    }
    
    // 初始化图表
    const initGraph = () => {
      if (!svg.value || !graphContainer.value) return
      
      const data = transformData()
      const container = graphContainer.value
      const width = container.clientWidth
      const height = container.clientHeight
      
      // 清空SVG
      d3.select(svg.value).selectAll("*").remove()
      
      // 创建SVG
      const svgElement = d3.select(svg.value)
        .attr('width', width)
        .attr('height', height)
      
      // 创建缩放行为
      const zoom = d3.zoom()
        .scaleExtent([0.1, 4])
        .on('zoom', (event) => {
          svgElement.select('.graph-group').attr('transform', event.transform)
        })
      
      svgElement.call(zoom)
      
      // 创建主组
      const g = svgElement.append('g').attr('class', 'graph-group')
      
      // 创建箭头标记
      g.append('defs').selectAll('marker')
        .data(['arrow'])
        .enter().append('marker')
        .attr('id', d => d)
        .attr('viewBox', '0 -5 10 10')
        .attr('refX', 15)
        .attr('refY', 0)
        .attr('markerWidth', 6)
        .attr('markerHeight', 6)
        .attr('orient', 'auto')
        .append('path')
        .attr('d', 'M0,-5L10,0L0,5')
        .attr('fill', '#666')
      
      // 创建连接线
      const link = g.append('g')
        .attr('class', 'links')
        .selectAll('line')
        .data(data.links)
        .enter().append('line')
        .attr('stroke', '#666')
        .attr('stroke-width', 2)
        .attr('marker-end', 'url(#arrow)')
        .on('mouseover', function(event, d) {
          d3.select(this).attr('stroke-width', 4).attr('stroke', '#409EFF')
          // 显示tooltip
          showEdgeTooltip(event, d)
        })
        .on('mouseout', function(event, d) {
          d3.select(this).attr('stroke-width', 2).attr('stroke', '#666')
          // 隐藏tooltip
          hideEdgeTooltip()
        })
      
      // 创建节点
      const node = g.append('g')
        .attr('class', 'nodes')
        .selectAll('circle')
        .data(data.nodes)
        .enter().append('circle')
        .attr('r', 8)
        .attr('fill', d => d.color)
        .attr('stroke', '#fff')
        .attr('stroke-width', 2)
        .call(d3.drag()
          .on('start', dragstarted)
          .on('drag', dragged)
          .on('end', dragended)
        )
        .on('click', (event, d) => {
          showNodeDetail.value = true
          selectedNode.value = d
        })
        .on('mouseover', function(event, d) {
          d3.select(this).attr('r', 12)
          // 高亮相关连接
          link.style('opacity', l => 
            l.source && l.target && (l.source.id === d.id || l.target.id === d.id) ? 1 : 0.1
          )
        })
        .on('mouseout', function(event, d) {
          d3.select(this).attr('r', 8)
          link.style('opacity', 1)
        })
      
      // 创建节点标签
      const label = g.append('g')
        .attr('class', 'labels')
        .selectAll('text')
        .data(data.nodes)
        .enter().append('text')
        .text(d => d.id.length > 10 ? d.id.substring(0, 10) + '...' : d.id)
        .attr('font-size', '12px')
        .attr('fill', '#333')
        .attr('text-anchor', 'middle')
        .attr('dy', '0.35em')
        .style('pointer-events', 'none')
      
      // 创建力导向模拟
      simulation.value = d3.forceSimulation(data.nodes)
        .force('link', d3.forceLink(data.links).id(d => d.id).distance(100))
        .force('charge', d3.forceManyBody().strength(-300))
        .force('center', d3.forceCenter(width / 2, height / 2))
        .force('collision', d3.forceCollide().radius(20))
        .on('tick', () => {
          if (!physicsEnabled.value) return
          link
            .attr('x1', d => d.source.x)
            .attr('y1', d => d.source.y)
            .attr('x2', d => d.target.x)
            .attr('y2', d => d.target.y)
          node
            .attr('cx', d => d.x)
            .attr('cy', d => d.y)
          label
            .attr('x', d => d.x)
            .attr('y', d => d.y)
        })
      
      // 拖拽函数
      function dragstarted(event, d) {
        if (!event.active) simulation.value.alphaTarget(0.3).restart()
        d.fx = d.x
        d.fy = d.y
      }
      
      function dragged(event, d) {
        d.fx = event.x
        d.fy = event.y
      }
      
      function dragended(event, d) {
        if (!event.active) simulation.value.alphaTarget(0)
        d.fx = null
        d.fy = null
      }
    }
    
    // 重置模拟
    const resetSimulation = () => {
      if (simulation.value) {
        simulation.value.alpha(1).restart()
      }
    }
    
    // 适应屏幕
    const fitToScreen = () => {
      if (!svg.value) return
      
      const svgElement = d3.select(svg.value)
      const transform = d3.zoomIdentity
        .translate(svg.value.clientWidth / 2, svg.value.clientHeight / 2)
        .scale(0.8)
      
      svgElement.transition().duration(750).call(
        d3.zoom().transform,
        transform
      )
    }
    
    // 切换物理引擎
    const togglePhysics = () => {
      physicsEnabled.value = !physicsEnabled.value
      if (simulation.value) {
        if (physicsEnabled.value) {
          simulation.value.alpha(1).restart()
        } else {
          simulation.value.stop()
        }
      }
    }
    
    // 导出图片
    const exportGraph = () => {
      if (!svg.value) return
      
      const svgElement = d3.select(svg.value)
      const svgData = new XMLSerializer().serializeToString(svg.value)
      const canvas = document.createElement('canvas')
      const ctx = canvas.getContext('2d')
      const img = new Image()
      
      canvas.width = svg.value.clientWidth
      canvas.height = svg.value.clientHeight
      
      img.onload = () => {
        ctx.drawImage(img, 0, 0)
        const link = document.createElement('a')
        link.download = 'knowledge-graph.png'
        link.href = canvas.toDataURL()
        link.click()
      }
      
      img.src = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgData)))
    }
    
    // 关闭节点详情
    const closeNodeDetail = () => {
      showNodeDetail.value = false
      selectedNode.value = null
    }
    
    // 悬浮提示dom
    let tooltipDiv = null
    const showEdgeTooltip = (event, d) => {
      if (!d.type && !d.description) return
      if (!tooltipDiv) {
        tooltipDiv = document.createElement('div')
        tooltipDiv.className = 'edge-tooltip'
        document.body.appendChild(tooltipDiv)
      }
      let html = ''
      if (d.type) html += `类型: ${d.type}`
      if (d.description) html += (html ? '\n' : '') + `描述: ${d.description}`
      tooltipDiv.innerText = html
      tooltipDiv.style.display = 'block'
      tooltipDiv.style.position = 'fixed'
      tooltipDiv.style.left = event.clientX + 12 + 'px'
      tooltipDiv.style.top = event.clientY + 12 + 'px'
      tooltipDiv.style.zIndex = 9999
      tooltipDiv.style.background = 'rgba(50,50,50,0.95)'
      tooltipDiv.style.color = '#fff'
      tooltipDiv.style.padding = '6px 12px'
      tooltipDiv.style.borderRadius = '6px'
      tooltipDiv.style.fontSize = '13px'
      tooltipDiv.style.pointerEvents = 'none'
      tooltipDiv.style.maxWidth = '320px'
      tooltipDiv.style.whiteSpace = 'pre-line'
      tooltipDiv.style.wordBreak = 'break-all'
    }
    const hideEdgeTooltip = () => {
      if (tooltipDiv) {
        tooltipDiv.style.display = 'none'
      }
    }
    
    // 监听数据变化
    watch([() => props.nodes, () => props.relationships], () => {
      nextTick(() => {
        initGraph()
      })
    }, { deep: true })
    
    // 监听窗口大小变化
    const handleResize = () => {
      nextTick(() => {
        initGraph()
      })
    }
    
    onMounted(() => {
      nextTick(() => {
        initGraph()
      })
      window.addEventListener('resize', handleResize)
    })
    
    onUnmounted(() => {
      if (simulation.value) {
        simulation.value.stop()
      }
      window.removeEventListener('resize', handleResize)
      if (tooltipDiv && tooltipDiv.parentNode) {
        tooltipDiv.parentNode.removeChild(tooltipDiv)
        tooltipDiv = null
      }
    })
    
    return {
      graphContainer,
      svg,
      physicsEnabled,
      showNodeDetail,
      selectedNode,
      resetSimulation,
      fitToScreen,
      togglePhysics,
      exportGraph,
      closeNodeDetail,
      getNodeColor
    }
  }
}
</script>

<style scoped>
.knowledge-graph-container {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
}

.graph-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
  padding: 8px 0;
}

.graph-controls {
  display: flex;
  gap: 8px;
}

.graph-stats {
  display: flex;
  gap: 16px;
  font-size: 12px;
  color: #666;
}

.graph-container {
  flex: 1;
  min-height: 500px;
  border: 1px solid #e4e7ed;
  border-radius: 6px;
  background: #fff;
  position: relative;
  overflow: hidden;
}

.graph-svg {
  width: 100%;
  height: 100%;
}

.node-detail {
  padding: 16px;
}

.detail-item {
  margin-bottom: 12px;
}

.detail-item label {
  font-weight: 500;
  color: #333;
  display: block;
  margin-bottom: 4px;
}

.properties-list {
  margin-top: 8px;
}

.property-item {
  display: flex;
  margin-bottom: 4px;
  padding: 4px 8px;
  background: #f8f9fa;
  border-radius: 4px;
}

.property-key {
  font-weight: 500;
  color: #666;
  margin-right: 8px;
  min-width: 80px;
}

.property-value {
  color: #333;
  word-break: break-word;
}

.edge-tooltip {
  box-shadow: 0 2px 12px rgba(0,0,0,0.15);
  transition: opacity 0.15s;
}
</style> 