import { createApp } from 'vue'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
import App from './App.vue'
import router from './router'
import api from './api'

const app = createApp(App)

// 注册所有图标
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component)
}

app.use(ElementPlus)
app.use(router)

// 应用启动时立即进行自动登录
console.log('应用启动，开始自动登录...');
localStorage.removeItem('auth_token')
// 触发一次请求来启动自动登录流程
api.get('/kg/list', { params: { pageNum: 1, pageSize: 1 } }).catch(() => {
  // 忽略错误，这只是为了触发自动登录
});

app.mount('#app') 