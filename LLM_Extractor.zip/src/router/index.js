import { createRouter, createWebHistory } from 'vue-router'
import AIExtract from '../views/AIExtract.vue'

const routes = [
  {
    path: '/',
    redirect: '/ai-extract'
  },
  {
    path: '/ai-extract',
    name: 'AIExtract',
    component: AIExtract
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router 