<template>
  <div class="ai-extract-container">
    <!-- 头部 -->
    <div class="header">
      <div class="header-content">
        <h1 class="title">
          <el-icon><MagicStick /></el-icon>
          AI知识图谱抽取系统
        </h1>
        <p class="subtitle">基于大模型的本体知识抽取工具</p>
      </div>
    </div>

    <!-- 主要内容区域 -->
    <div class="main-content">
      <el-row :gutter="24">
        <!-- 左侧配置面板 -->
        <el-col :span="10">
          <div class="config-panel">
            <h3 class="panel-title">
              <el-icon><Setting /></el-icon>
              抽取配置
            </h3>
            
            <!-- 知识图谱选择 -->
            <div class="config-section">
              <label class="section-label">选择知识图谱</label>
              <el-select 
                v-model="selectedKG" 
                placeholder="请选择知识图谱"
                @change="onKGChange"
                style="width: 100%"
              >
                <el-option
                  v-for="kg in kgList"
                  :key="String(kg.id)"
                  :label="kg.nameCn"
                  :value="String(kg.id)"
                >
                  <span>{{ kg.nameCn }}</span>
                  <span style="float: right; color: #8492a6; font-size: 13px">
                    {{ kg.graphIri }}
                  </span>
                </el-option>
              </el-select>
            </div>

            <!-- 文件上传 -->
            <div class="config-section">
              <label class="section-label">上传文档</label>
              <el-upload
                ref="uploadRef"
                :auto-upload="false"
                :on-change="handleFileChange"
                :show-file-list="true"
                :limit="1"
                accept=".txt,.doc,.docx,.pdf"
                :file-list="uploadFileList"
                drag
              >
                <el-icon class="el-icon--upload"><UploadFilled /></el-icon>
                <div class="el-upload__text">
                  将文件拖到此处，或<em>点击上传</em>
                </div>
                <template #tip>
                  <div class="el-upload__tip">
                    支持 txt、doc、docx、pdf 格式，文件大小不超过 50MB
                  </div>
                </template>
              </el-upload>
            </div>

            <!-- 抽取参数配置 -->
            <div class="config-section">
              <label class="section-label">抽取参数</label>
              
              <div class="param-item">
                <label>分片大小 (token)</label>
                <el-input-number 
                  v-model="extractParams.chunkSize" 
                  :min="500" 
                  :max="5000" 
                  :step="100"
                  style="width: 100%"
                />
              </div>

              <div class="param-item">
                <label>分片重叠 (token)</label>
                <el-input-number 
                  v-model="extractParams.chunkOverlap" 
                  :min="100" 
                  :max="1000" 
                  :step="50"
                  style="width: 100%"
                />
              </div>

              <div class="param-item">
                <label>并行线程数</label>
                <el-input-number 
                  v-model="extractParams.parallelThreads" 
                  :min="1" 
                  :max="8" 
                  :step="1"
                  style="width: 100%"
                />
              </div>

              <div class="param-item">
                <el-checkbox v-model="extractParams.enableOntologyValidation">
                  启用本体校验
                </el-checkbox>
              </div>

              <div class="param-item">
                <el-checkbox v-model="extractParams.enableDeduplication">
                  启用去重合并
                </el-checkbox>
              </div>
            </div>

            <!-- 自定义Prompt -->
            <div class="config-section">
              <el-card shadow="never" style="margin-bottom: 0;">
                <template #header>
                  <div style="display: flex; align-items: center; justify-content: space-between;">
                    <span><el-icon><View /></el-icon> Prompt 预览 (只读)</span>
                    <div style="display: flex; gap: 8px;">
                      <el-button size="small" @click="loadDefaultPrompt" :disabled="!selectedKG">加载默认模板</el-button>
                      <el-button size="small" @click="showPromptPreview" :disabled="!promptPreview">预览/复制</el-button>
                    </div>
                  </div>
                </template>
                <div style="padding: 16px; background: #f8f9fa; border-radius: 6px; color: #666; min-height: 120px;">
                  <div v-if="promptPreview" style="font-family: monospace; white-space: pre-wrap; max-height: 200px; overflow: hidden; position: relative; line-height: 1.5; font-size: 13px;">
                    {{ promptPreview }}
                    <div v-if="promptPreview.length > 500" style="position: absolute; bottom: 0; right: 0; background: linear-gradient(transparent, #f8f9fa); width: 100%; height: 30px;"></div>
                  </div>
                  <div v-else style="color: #999; text-align: center; padding: 20px;">点击"加载默认模板"查看Prompt内容</div>
                </div>
                <div style="margin-top: 8px; color: #999; font-size: 13px;">提示：Prompt仅用于预览，不会传递给后端，实际抽取使用后端默认模板。</div>
              </el-card>
            </div>

            <!-- 操作按钮 -->
            <div class="action-buttons">
              <el-button 
                type="primary" 
                size="large" 
                @click="startExtract('sync')"
                :loading="loading.sync"
                :disabled="!canExtract"
                style="width: 48%"
              >
                <el-icon><VideoPlay /></el-icon>
                {{ loading.sync ? '抽取中...' : '同步抽取' }}
              </el-button>
              <el-button 
                type="success" 
                size="large" 
                @click="startExtract('async')"
                :loading="loading.async"
                :disabled="!canExtract"
                style="width: 48%"
              >
                <el-icon><Clock /></el-icon>
                异步抽取
              </el-button>
            </div>
          </div>
        </el-col>

        <!-- 右侧结果展示 -->
        <el-col :span="14">
          <div class="result-panel">
            <el-upload
              class="manual-json-upload"
              :show-file-list="false"
              accept=".json"
              :before-upload="handleLocalJsonUpload"
            >
              <el-button size="small" type="primary">手动加载本地JSON文件</el-button>
            </el-upload>
            <!-- 进度监控 -->
            <div v-if="currentTask" class="progress-section">
              <h3 class="panel-title">
                <el-icon><Loading /></el-icon>
                抽取进度
              </h3>
              <div class="progress-content">
                <el-progress 
                  :percentage="currentTask.progress || 0" 
                  :status="getProgressStatus()"
                  :stroke-width="8"
                />
                <div class="progress-info">
                  <span>状态: {{ currentTask.statusInfo || '准备中' }}</span>
                  <span v-if="currentTask.descObj">
                    已处理: {{ currentTask.descObj.processedChunks || 0 }} / {{ currentTask.descObj.totalChunks || 0 }}
                  </span>
                </div>
                <!-- 显示后端返回的执行信息 -->
                <div v-if="currentTask.message" class="progress-message">
                  <el-alert 
                    :title="currentTask.message" 
                    type="info" 
                    show-icon 
                    :closable="false"
                  />
                </div>
                <div v-if="currentTask.error" class="error-message">
                  <el-alert 
                    :title="currentTask.error" 
                    type="error" 
                    show-icon 
                    :closable="false"
                  />
                </div>
                <!-- 显示结果下载链接 -->
                <div v-if="currentTask.result && currentTask.status === 3" class="result-link">
                  <el-alert 
                    title="抽取结果已生成" 
                    type="success" 
                    show-icon 
                    :closable="false"
                  >
                    <template #default>
                      <div>结果文件: <a :href="currentTask.result" target="_blank">{{ currentTask.result }}</a></div>
                    </template>
                  </el-alert>
                </div>
              </div>
            </div>

            <!-- 抽取结果 -->
            <div v-if="extractResult" class="result-section">
              <h3 class="panel-title">
                <el-icon><DataAnalysis /></el-icon>
                抽取结果
                <!-- 仅异步抽取且有result时显示保存按钮 -->
                <el-button 
                  v-if="currentTask && currentTask.result && currentTask.status === 3" 
                  size="small" 
                  type="primary" 
                  @click="saveToGraphDB"
                  :loading="loading.save"
                  style="float: right"
                >
                  保存到图谱
                </el-button>
              </h3>
              
              <div class="result-stats">
                <el-row :gutter="16">
                  <el-col :span="8">
                    <div class="stat-card">
                      <div class="stat-number">{{ extractResult.nodes?.length || 0 }}</div>
                      <div class="stat-label">实体数量</div>
                    </div>
                  </el-col>
                  <el-col :span="8">
                    <div class="stat-card">
                      <div class="stat-number">{{ extractResult.relationships?.length || 0 }}</div>
                      <div class="stat-label">关系数量</div>
                    </div>
                  </el-col>
                  <el-col :span="8">
                    <div class="stat-card">
                      <div class="stat-number">{{ uniqueEntityTypes.length }}</div>
                      <div class="stat-label">实体类型</div>
                    </div>
                  </el-col>
                </el-row>
              </div>

              <!-- 结果详情 -->
              <div class="result-details">
                <el-tabs v-model="activeTab">
                  <el-tab-pane label="知识图谱" name="knowledge-graph">
                    <div class="graph-section">
                      <KnowledgeGraph 
                        :nodes="extractResult.nodes || []"
                        :relationships="extractResult.relationships || []"
                      />
                    </div>
                  </el-tab-pane>
                  
                  <el-tab-pane label="实体列表" name="entities">
                    <div class="entity-list">
                      <el-table :data="extractResult.nodes || []" height="400" stripe>
                        <el-table-column prop="id" label="实体ID" width="200" />
                        <el-table-column prop="type" label="实体类型" width="150" />
                        <el-table-column label="属性" min-width="300">
                          <template #default="{ row }">
                            <el-tag 
                              v-for="(value, key) in row.properties" 
                              :key="key"
                              size="small"
                              style="margin: 2px"
                            >
                              {{ key }}: {{ value }}
                            </el-tag>
                          </template>
                        </el-table-column>
                      </el-table>
                    </div>
                  </el-tab-pane>
                  
                  <el-tab-pane label="关系列表" name="relationships">
                    <div class="relationship-list">
                      <el-table :data="extractResult.relationships || []" height="400" stripe>
                        <el-table-column prop="sourceNodeId" label="源实体" width="200" />
                        <el-table-column prop="type" label="关系类型" width="150" />
                        <el-table-column prop="targetNodeId" label="目标实体" width="200" />
                        <el-table-column prop="description" label="描述" min-width="200" />
                      </el-table>
                    </div>
                  </el-tab-pane>
                </el-tabs>
              </div>
            </div>

            <!-- 空状态 -->
            <div v-if="!currentTask && !extractResult" class="empty-state">
              <el-empty description="请选择知识图谱并上传文档开始抽取">
                <el-icon size="60" color="#909399"><Document /></el-icon>
              </el-empty>
            </div>
          </div>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
import { ref, reactive, computed, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { aiExtractAPI, kgAPI } from '../api/aiExtract'
import JSONbig from 'json-bigint'
import KnowledgeGraph from '../components/KnowledgeGraph.vue'

export default {
  name: 'AIExtract',
  components: {
    KnowledgeGraph
  },
  setup() {
    // 响应式数据
    const kgList = ref([])
    const selectedKG = ref('')
    const uploadRef = ref(null)
    const uploadFileList = ref([])
    const activeTab = ref('knowledge-graph')
    
    const extractParams = reactive({
      chunkSize: 2000,
      chunkOverlap: 500,
      parallelThreads: 4,
      enableOntologyValidation: true,
      enableDeduplication: true
    })

    const loading = reactive({
      sync: false,
      async: false,
      save: false
    })

    const currentTask = ref(null)
    const extractResult = ref(null)
    const progressTimer = ref(null)
    const promptPreview = ref('')

    // 计算属性
    const canExtract = computed(() => {
      const hasKG = !!selectedKG.value
      
      // 检查多种可能的文件列表属性
      const uploadFiles = uploadRef.value?.uploadFiles || []
      const fileList = uploadRef.value?.fileList || []
      const hasFiles = uploadFiles.length > 0 || fileList.length > 0 || uploadFileList.value.length > 0
      
      return hasKG && hasFiles
    })

    const uniqueEntityTypes = computed(() => {
      if (!extractResult.value?.nodes) return []
      const types = new Set(extractResult.value.nodes.map(node => node.type))
      return Array.from(types)
    })

    // 方法
    const loadKGList = async () => {
      try {
        const response = await kgAPI.getKGList({ pageNum: 1, pageSize: 100 })
        kgList.value = response.data?.rows || []
      } catch (error) {
        ElMessage.error('加载知识图谱列表失败')
      }
    }

    const onKGChange = () => {
      extractResult.value = null
      currentTask.value = null
    }

    const handleFileChange = (file) => {
      if (file.size > 50 * 1024 * 1024) {
        ElMessage.error('文件大小不能超过50MB')
        return false
      }
      // 更新文件列表
      uploadFileList.value = [file]
    }

    const formatPrompt = (raw) => {
      if (!raw) return ''
      let str = raw.replace(/\\n/g, '\n')
      str = str.replace(/^[ \t]+/gm, '')
      const lines = str.split('\n')
      return lines.join('\n').trim()
    }

    const loadDefaultPrompt = async () => {
      if (!selectedKG.value) {
        ElMessage.warning('请先选择知识图谱')
        return
      }
      try {
        const promptResp = await aiExtractAPI.getDefaultPrompt(selectedKG.value)
        // 兼容后端返回结构
        let prompt = promptResp.data || promptResp
        promptPreview.value = formatPrompt(prompt)
        ElMessage.success('默认模板加载成功')
        // 弹窗预览
        showPromptPreview()
      } catch (error) {
        ElMessage.error('加载默认模板失败')
      }
    }

    const showPromptPreview = () => {
      ElMessageBox({
        title: 'Prompt 预览',
        message: `<pre style=\"white-space:pre-wrap;word-break:break-all;font-family:monospace;font-size:13px;max-height:60vh;overflow:auto;line-height:1.5;width:100%;max-width:100%;\">${promptPreview.value.replace(/</g,'&lt;')}</pre>`,
        dangerouslyUseHTMLString: true,
        showCancelButton: true,
        confirmButtonText: '复制',
        cancelButtonText: '关闭',
        customClass: 'prompt-preview-dialog',
        callback: (action) => {
          if (action === 'confirm') {
            navigator.clipboard.writeText(promptPreview.value)
            ElMessage.success('Prompt已复制到剪贴板')
          }
        }
      }).then(() => {
        // 弹窗打开后，动态设置样式
        setTimeout(() => {
          const messageBox = document.querySelector('.prompt-preview-dialog')
          const preElement = document.querySelector('.prompt-preview-dialog pre')
          if (messageBox) {
            messageBox.style.width = '90vw'
            messageBox.style.maxWidth = '1600px'
          }
          if (preElement) {
            preElement.style.width = '100%'
            preElement.style.maxWidth = '100%'
            preElement.style.display = 'block'
          }
        }, 100)
      })
    }

    const startExtract = async (type) => {
      if (!canExtract.value) {
        ElMessage.warning('请选择知识图谱并上传文档')
        return
      }

      // 尝试从多个可能的属性获取文件
      const uploadFiles = uploadRef.value?.uploadFiles || []
      const fileList = uploadRef.value?.fileList || []
      const file = uploadFiles[0] || fileList[0] || uploadFileList.value[0]
      
      if (!file) {
        ElMessage.warning('请先上传文档')
        return
      }

      const formData = new FormData()
      formData.append('file', file.raw)
      formData.append('kgId', String(selectedKG.value))
      formData.append('chunkSize', extractParams.chunkSize)
      formData.append('chunkOverlap', extractParams.chunkOverlap)
      formData.append('parallelThreads', extractParams.parallelThreads)
      formData.append('enableOntologyValidation', extractParams.enableOntologyValidation)
      formData.append('enableDeduplication', extractParams.enableDeduplication)

      loading[type] = true
      extractResult.value = null

      try {
        if (type === 'sync') {
          // 同步抽取
          const result = await aiExtractAPI.extractSync(formData)
          extractResult.value = result
          ElMessage.success('抽取完成！')
        } else {
          // 异步抽取
          const response = await aiExtractAPI.extractAsync(formData)
          
          // 从正确的路径获取taskId
          const taskId = response.data?.taskId || response.taskId
          
          if (!taskId) {
            throw new Error('未获取到任务ID')
          }
          
          currentTask.value = { taskId: taskId, progress: 0, statusInfo: '任务已启动' }
          ElMessage.success('异步任务已启动，正在监控进度...')
          startProgressMonitoring(taskId)
        }
      } catch (error) {
        ElMessage.error('抽取失败：' + (error.message || '未知错误'))
      } finally {
        loading[type] = false
      }
    }

    const startProgressMonitoring = (taskId) => {
      progressTimer.value = setInterval(async () => {
        try {
          const progressResponse = await aiExtractAPI.getProgress(taskId)
          
          // 处理响应结构，兼容不同的返回格式
          const progressData = progressResponse.data || progressResponse
          currentTask.value = progressData
          
          if (progressData.status === 3) { // 完成
            clearInterval(progressTimer.value)
            progressTimer.value = null
            ElMessage.success(`抽取任务完成！${progressData.message || ''}`)
            
            // 如果有结果下载链接，自动加载结果
            if (progressData.result) {
              loadExtractResult(progressData.result)
            }
          } else if (progressData.status === 2) { // 错误
            clearInterval(progressTimer.value)
            progressTimer.value = null
            ElMessage.error(`抽取任务失败：${progressData.error || progressData.message || '未知错误'}`)
          } else if (progressData.status === 1) { // 执行中
            // 继续监控，可以显示进度信息
            if (progressData.message) {
            }
          }
        } catch (error) {
        }
      }, 5000)
    }

    const getProgressStatus = () => {
      if (!currentTask.value) return ''
      if (currentTask.value.status === 2) return 'exception'  // 失败
      if (currentTask.value.status === 3) return 'success'    // 成功
      return ''  // 执行中或准备中
    }

    const saveToGraphDB = async () => {
      if (!extractResult.value || !selectedKG.value) {
        ElMessage.warning('没有可保存的结果');
        return;
      }
      // 仅支持异步抽取的保存
      let jsonPath = '';
      if (currentTask.value && currentTask.value.result) {
        jsonPath = currentTask.value.result;
      } else {
        ElMessage.warning('仅支持异步抽取结果保存，未找到抽取结果文件路径');
        return;
      }
      try {
        await ElMessageBox.confirm(
          '确定要将抽取结果保存到知识图谱中吗？',
          '确认保存',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }
        );
        loading.save = true;
        const resp = await aiExtractAPI.loadToGraphDB(selectedKG.value, jsonPath);
        if (resp && resp.data && (resp.data.success || resp.data.code === 0)) {
          ElMessage.success('保存成功！');
        } else {
          ElMessage.success('保存请求已发送，具体结果请查看后端日志或页面刷新后确认。');
        }
      } catch (error) {
        if (error !== 'cancel') {
          ElMessage.error('保存失败：' + (error.message || '未知错误'));
        }
      } finally {
        loading.save = false;
      }
    };

    const loadExtractResult = async (resultUrl) => {
      try {
        const response = await fetch(resultUrl)
        const resultData = await response.json()
        handleAsyncResult(resultData)
        ElMessage.success('异步抽取完成，结果已加载')
      } catch (error) {
        ElMessage.error('加载抽取结果失败')
      }
    }

    const transformGraphData = (data) => {
      if (!data || !data.entities || !data.relationships) {
        return { nodes: [], relationships: [] }
      }
      
      // 转换实体为节点格式
      const nodes = data.entities.map(entity => ({
        id: entity.id,
        type: entity.type,
        properties: entity.properties || {}
      }))
      
      // 转换关系格式
      const relationships = data.relationships.map(rel => ({
        sourceNodeId: rel.sourceNodeId,
        targetNodeId: rel.targetNodeId,
        type: rel.type,
        description: rel.description
      }))
      
      return { nodes, relationships }
    }

    const handleAsyncResult = (resultData) => {
      try {
        const graphData = transformGraphData(resultData)
        extractResult.value = graphData
        activeTab.value = 'knowledge-graph'
      } catch (error) {
        ElMessage.error('处理提取结果失败')
      }
    }

    const handleLocalJsonUpload = (file) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const json = JSON.parse(e.target.result);
          let nodes = [];
          let relationships = [];
          if (Array.isArray(json.nodes) && Array.isArray(json.relationships)) {
            nodes = json.nodes;
            relationships = json.relationships;
          } else if (Array.isArray(json.entities) && Array.isArray(json.relationships)) {
            nodes = json.entities;
            relationships = json.relationships;
          } else {
            ElMessage.error('JSON格式不正确，需包含 nodes/entities 和 relationships');
            return false;
          }
          extractResult.value = { nodes, relationships };
          activeTab.value = 'knowledge-graph';
          ElMessage.success('本地JSON加载成功');
        } catch (err) {
          ElMessage.error('JSON解析失败: ' + err.message);
        }
      };
      reader.readAsText(file);
      return false;
    }

    // 生命周期
    onMounted(() => {
      loadKGList()
    })

    return {
      kgList,
      selectedKG,
      uploadRef,
      uploadFileList,
      activeTab,
      extractParams,
      loading,
      currentTask,
      extractResult,
      promptPreview,
      canExtract,
      uniqueEntityTypes,
      onKGChange,
      handleFileChange,
      loadDefaultPrompt,
      showPromptPreview,
      startExtract,
      getProgressStatus,
      saveToGraphDB,
      formatPrompt,
      loadExtractResult,
      transformGraphData,
      handleAsyncResult,
      handleLocalJsonUpload
    }
  }
}
</script>

<style scoped>
.ai-extract-container {
  min-height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.header {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  padding: 20px 0;
  margin-bottom: 30px;
}

.header-content {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
  text-align: center;
}

.title {
  color: white;
  font-size: 2.5rem;
  margin: 0 0 10px 0;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
}

.subtitle {
  color: rgba(255, 255, 255, 0.8);
  font-size: 1.1rem;
  margin: 0;
}

.main-content {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}

.config-panel, .result-panel {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
  height: fit-content;
}

.panel-title {
  margin: 0 0 20px 0;
  font-size: 1.2rem;
  color: #303133;
  display: flex;
  align-items: center;
  gap: 8px;
  border-bottom: 2px solid #f0f0f0;
  padding-bottom: 12px;
}

.config-section {
  margin-bottom: 24px;
}

.section-label {
  display: block;
  margin-bottom: 8px;
  font-weight: 500;
  color: #606266;
}

.param-item {
  margin-bottom: 16px;
}

.param-item label {
  display: block;
  margin-bottom: 6px;
  font-size: 14px;
  color: #606266;
}

.prompt-actions {
  margin-top: 8px;
  display: flex;
  gap: 8px;
}

.action-buttons {
  display: flex;
  gap: 12px;
  margin-top: 24px;
}

.progress-section {
  margin-bottom: 24px;
}

.progress-content {
  padding: 16px;
  background: #f8f9fa;
  border-radius: 8px;
}

.progress-info {
  margin-top: 12px;
  display: flex;
  justify-content: space-between;
  font-size: 14px;
  color: #606266;
}

.progress-message {
  margin-top: 12px;
}

.error-message {
  margin-top: 12px;
}

.result-stats {
  margin-bottom: 24px;
}

.stat-card {
  text-align: center;
  padding: 20px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border-radius: 8px;
}

.stat-number {
  font-size: 2rem;
  font-weight: bold;
  margin-bottom: 8px;
}

.stat-label {
  font-size: 14px;
  opacity: 0.9;
}

.result-details {
  background: #f8f9fa;
  border-radius: 8px;
  padding: 16px;
}

.graph-section {
  height: 600px;
  width: 100%;
  border: 1px solid #e4e7ed;
  border-radius: 6px;
  background: #fff;
  overflow: hidden;
}

.entity-list, .relationship-list {
  max-height: 400px;
  overflow-y: auto;
}

.empty-state {
  text-align: center;
  padding: 60px 20px;
  color: #909399;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .main-content {
    padding: 0 10px;
  }
  
  .title {
    font-size: 2rem;
  }
  
  .action-buttons {
    flex-direction: column;
  }
  
  .action-buttons .el-button {
    width: 100% !important;
  }
}

/* Prompt预览弹窗样式 */
:deep(.prompt-preview-dialog) {
  width: 90vw !important;
  max-width: 1600px !important;
}

:deep(.prompt-preview-dialog .el-message-box__content) {
  max-height: 70vh;
  overflow: auto;
  width: 100% !important;
}

:deep(.prompt-preview-dialog .el-message-box__message) {
  width: 100% !important;
  max-width: 100% !important;
}

:deep(.prompt-preview-dialog pre) {
  background: #f8f9fa;
  padding: 16px;
  border-radius: 6px;
  border: 1px solid #e4e7ed;
  margin: 0;
  width: 100% !important;
  max-width: 100% !important;
  box-sizing: border-box;
  display: block !important;
}

/* 全局弹窗样式覆盖 */
:global(.el-message-box.prompt-preview-dialog) {
  width: 90vw !important;
  max-width: 1600px !important;
}

:global(.el-message-box.prompt-preview-dialog .el-message-box__content) {
  max-height: 70vh;
  overflow: auto;
  width: 100% !important;
}

:global(.el-message-box.prompt-preview-dialog .el-message-box__message) {
  width: 100% !important;
  max-width: 100% !important;
}

:global(.el-message-box.prompt-preview-dialog pre) {
  background: #f8f9fa;
  padding: 16px;
  border-radius: 6px;
  border: 1px solid #e4e7ed;
  margin: 0;
  width: 100% !important;
  max-width: 100% !important;
  box-sizing: border-box;
  display: block !important;
}

.manual-json-upload {
  margin-bottom: 12px;
}
</style> 