#!/bin/bash
echo "正在启动STKG AI知识图谱抽取前端..."
echo ""
echo "请确保已安装Node.js和npm"
echo "如果未安装依赖，请先运行: npm install"
echo ""
echo "启动开发服务器..."
npm run dev 